# Obor Hisoboti — Telegram Mini App

## GitHub'ga yuklash

1. github.com → "New repository" → `obor-hisoboti` → Create
2. Bu papkadagi barcha fayllarni yuklang (Upload files)

## Vercel'ga ulash

1. vercel.com → "Add New Project"
2. GitHub repository'ni tanlang: `obor-hisoboti`
3. Framework: **Vite**
4. Deploy tugmasini bosing
5. Sizga link beriladi: `https://obor-hisoboti.vercel.app`

## Telegram Mini App ulash

1. Telegramda @BotFather → `/newbot`
2. Bot nomi: `Obor Hisoboti`
3. Username: `obor_hisoboti_bot`
4. Token'ni saqlang
5. `/newapp` → botni tanlang → Vercel linkni kiriting
6. Tayyor! 🎉
